import { UserType } from "@/lib/types/UserType";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { useState } from "react";
import { Button } from "../ui/button";
import { toast } from "sonner";
import { CgCloseO } from "react-icons/cg";
import { SendPasswordReset, updateUser } from "@/lib/firebase";

type Props = {
  user: UserType;
  closeDialog: () => void;
  fetchAllUsers: () => void;
};

function UpdateUserModel({ user, closeDialog, fetchAllUsers }: Props) {
  const [fullName, setFullName] = useState(user.fullName);
  const [email, setEmail] = useState(user.email);
  const [isUpdating, setIsUpdating] = useState(false);
  const [resettingPassword, setResettingPassword] = useState(false);


  const editUser = async () => {
    if (fullName.trim() && email.trim()) {
      try {
        setIsUpdating(true);
        const res = await updateUser({
          uid: user.uid,
          createdAt: user.createdAt,
          email: email,
          fullName: fullName,
        })

        if (res.result === 'success') {
          toast.success("User Updated Successfully.")
        } else {
          toast.error(res.message);
        }

        closeDialog();
        fetchAllUsers();

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } catch (error: any) {
        setIsUpdating(false);
        toast.error(error?.message ?? "Couldn't update the user.")
      }
    } else {
      toast.warning("Fill All User Details");
    }
  };

  const sendResetPasswordEmail = async (email: string) => {
    try {
      setResettingPassword(true);
      const res = await SendPasswordReset(email);
      if (res.result === "success") {
        toast.success(res.message);
        closeDialog();
      } else {
        toast.error(res.message);
      }
      setResettingPassword(false);


      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      setResettingPassword(false);
      toast.error(error?.message ?? "Something went wrong. Please try again.");
    }
  };

  return (
    <section className="fixed top-0 left-0 w-full h-full bg-black/40 z-50 flex items-center justify-center">
      <section className="relative w-full max-w-md bg-white rounded-xl shadow-md py-6 px-5 slideUpFadeInAnimation">
        <h2 className="text-xl font-bold text-center text-black">
          Update User Details
        </h2>

        <button
          className="w-fit h-fit absolute top-4 right-4 text-black"
          onClick={() => closeDialog()}
        >
          <CgCloseO size={26} />
        </button>

        <section className="w-full flex flex-col gap-4">
          <Label htmlFor="fullName">
            Full Name
            <Input
              type="text"
              name="fullName"
              id="fullName"
              placeholder="Full Name"
              className="w-full mt-2"
              value={fullName}
              onChange={(e) => {
                setFullName(e.target.value);
              }}
            />
          </Label>

          <Label htmlFor="email">
            Email
            <Input
              type="email"
              name="email"
              id="email"
              placeholder="Email"
              className="w-full mt-2"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />
          </Label>
          <Button
            onClick={() => {
              editUser();
            }}
            disabled={isUpdating}
          >
            {isUpdating ? "Updating User..." : "Update User"}
          </Button>
          <Button
            onClick={() => {
              sendResetPasswordEmail(user.email);
            }}
            disabled={resettingPassword}
            variant={"secondary"}
          >
            {resettingPassword ? "Resetting Password..." : "Reset Password"}
          </Button>

        </section>
      </section>
    </section>
  );
}

export default UpdateUserModel;
