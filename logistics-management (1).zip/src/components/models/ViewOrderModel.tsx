import { formatDate, getTimeFromDate } from "@/lib/formatDate";
import { OrderType } from "@/lib/types/OrderType";
import { CgCloseO } from "react-icons/cg";

type Props = {
  order: OrderType;
  closeDialog: () => void;
};

function ViewOrderModel({ order, closeDialog }: Props) {

  return (
    <section className="fixed top-0 left-0 w-full h-full bg-black/40 z-50 flex items-center justify-center">
      <section className="relative w-full max-w-3xl bg-white rounded-xl shadow-md py-6 px-5 slideUpFadeInAnimation">
        <h2 className="text-xl font-bold text-center text-black">
          Order Details
        </h2>

        <button
          className="w-fit h-fit absolute top-4 right-4 text-black"
          onClick={() => closeDialog()}
        >
          <CgCloseO size={26} />
        </button>

        <section className="grid grid-cols-2  mt-5">
          <section className="flex flex-col gap-y-1.5">
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Tracking Id:</p>
              <p className="text-base font-normal">{order.id}</p>
            </div>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Status:</p>
              <p className="text-base font-normal capitalize">{order.status}</p>
            </div>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Weight:</p>
              <p className="text-base font-normal">{order.weight} KG</p>
            </div>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Packaging Type:</p>
              <p className="text-base font-normal">
                {order.isWithCustomPackaging ? "Custom" : "Standard"}
              </p>
            </div>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Payment Option:</p>
              <p className="text-base font-normal">
                {order.paymentOption === "cod" ? "Cash On Delivery" : "Prepaid"}
              </p>
            </div>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Order Amount:</p>
              <p className="text-base font-normal">
                PKR {order.paymentOption === "cod" ? order.orderAmount : 0}
              </p>
            </div>

            <hr className="mt-3" />
            <p className="text-lg font-bold mt-2">Sender</p>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Name:</p>
              <p className="text-base font-normal">{order.sender.name}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Phone:</p>
              <p className="text-base font-normal">{order.sender.phone}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Email:</p>
                <p className="text-base font-normal">{order.sender.email}</p>
              </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">City:</p>
              <p className="text-base font-normal">{order.sender.city}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32 min-w-32">Address:</p>
              <p className="text-base font-normal">{order.sender.address}</p>
            </div>
            <hr className="mt-3" />
            <p className="text-lg font-bold mt-2">Receiver</p>

            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Name:</p>
              <p className="text-base font-normal">{order.receiver.name}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">Phone:</p>
              <p className="text-base font-normal">{order.receiver.phone}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Email:</p>
                <p className="text-base font-normal">{order.receiver.email}</p>
              </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32">City:</p>
              <p className="text-base font-normal">{order.receiver.city}</p>
            </div>
            <div className="w-full flex items-baseline gap-2">
              <p className="text-base font-bold w-32 min-w-32">Address:</p>
              <p className="text-base font-normal">{order.receiver.address}</p>
            </div>
          </section>

          <section className="w-full border-l border-black/10 pl-5">
            <h3 className="text-base font-bold text-center">Updates</h3>
            <section className="h-full ml-3 border-l border-black/30 flex flex-col gap- y-3">
              {order.updates.map((update, index) => {
                return (
                  <section key={index} className="pl-5 relative py-3">
                    <div className="absolute -left-1.5 top-[1.1rem] w-3 h-3 bg-gray-700 rounded-full"></div>
                    <p className="text-base font-bold">{update.location}</p>
                    <p className="text-sm">
                      {formatDate({
                        format: "DD MMM YYYY",
                        unformatedDate: update.createdAt,
                      })}{" "}
                      - {getTimeFromDate(update.createdAt)}
                    </p>
                    <p className="text-sm">{update.message}</p>
                  </section>
                );
              })}
            </section>
          </section>
        </section>
      </section>
    </section>
  );
}

export default ViewOrderModel;
