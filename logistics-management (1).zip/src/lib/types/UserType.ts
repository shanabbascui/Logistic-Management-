type UserType = {
    uid: string;
    fullName: string;
    email: string;
    createdAt: string;
};

export type { UserType }