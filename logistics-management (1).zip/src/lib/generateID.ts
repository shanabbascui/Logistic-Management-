function generateUniqueId(): string {
    const timestamp = Date.now().toString(16); // Convert current timestamp to hexadecimal string
    const randomPart = Math.random().toString(16).substr(2, 4); // Generate a random hexadecimal string

    // Combine timestamp and random part to create a unique ID
    const uniqueId = timestamp + randomPart;

    // Trim the ID to make it 8 characters long
    return uniqueId.substr(0, 8);
}

export { generateUniqueId };