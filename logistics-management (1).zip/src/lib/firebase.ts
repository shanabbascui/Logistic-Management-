/* eslint-disable @typescript-eslint/no-explicit-any */
import { initializeApp } from "firebase/app";
import {
  addDoc,
  collection,
  deleteDoc,
  getDocs,
  getFirestore,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { OrderType } from "./types/OrderType";
import {
  createUserWithEmailAndPassword,
  getAuth,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import { UserType } from "./types/UserType";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_APP_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_APP_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_APP_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_APP_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const db = getFirestore(app);

const auth = getAuth(app);

// Functions That are neede

// Get all Orders
const getOrders = async () => {
  // Get a list of all orders
  try {
    const q = query(collection(db, "orders"));
    const docs = await getDocs(q);
    const orders = docs.docs.map((doc) => doc.data());
    return {
      result: "success",
      message: "Orders retrieved successfully",
      data: orders,
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't get orders from the database",
      data: [],
    };
  }
};

// Get Order by ID
const getOrderById = async (id: string) => {
  try {
    const q = query(collection(db, "orders"), where("id", "==", id));
    const docs = await getDocs(q);

    if (docs.docs.length === 0)
      return {
        result: "error",
        message: "Order not found",
        data: {},
      };

    const order = docs.docs[0].data();
    return {
      result: "success",
      message: "Order retrieved successfully",
      data: order,
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't get order from the database",
      data: {},
    };
  }
};

// Add a Order
const addOrder = async (order: OrderType) => {
  try {
    await addDoc(collection(db, "orders"), order);

    return {
      result: "success",
      message: "Order added successfully",
      data: {},
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't add order to the database",
      data: {},
    };
  }
};

// Update a Order
const updateOrder = async (order: OrderType) => {
  try {
    const q = query(collection(db, "orders"), where("id", "==", order.id));
    const docs = await getDocs(q);

    const docRef = docs.docs[0].ref;

    updateDoc(docRef, order);

    return {
      result: "success",
      message: "Order updated successfully",
      data: {},
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't update order in the database",
      data: {},
    };
  }
};

// Delete a Order
const deleteOrder = async (id: string) => {
  try {
    const q = query(collection(db, "orders"), where("id", "==", id));

    const docs = await getDocs(q);
    const docRef = docs.docs[0].ref;
    await deleteDoc(docRef);

    return {
      result: "success",
      message: "Order deleted successfully",
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't delete order from the database",
    };
  }
};

// -------------------------------------------------------------

// Authentication Functions

// Login with Email and Password
const loginWithEmailPassword = async (email: string, password: string) => {
  try {
    const res = await signInWithEmailAndPassword(auth, email, password);
    const user = res.user;
    const q = query(collection(db, "users"), where("uid", "==", user.uid));
    const docs = await getDocs(q);
    if (docs?.docs?.length > 0) {
      return {
        result: "success",
        message: "Logged In Successfully",
        user: {
          profile: docs?.docs[0]?.data(),
        },
      };
    } else {
      Logout();
      return {
        result: "error",
        message: "User not found in the database",
        user: null,
      };
    }
  } catch (err: any) {
    return {
      result: "error",
      message: err.message,
      user: null,
    };
  }
};

// 3- Reset Password
const SendPasswordReset = async (email: string) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return {
      result: "success",
      message: "Password Reset Email Sent Successfully",
    };
  } catch (err: any) {
    return {
      result: "error",
      message: err.message,
    };
  }
};

// 4- Functions for Logout
const Logout = () => {
  signOut(auth);
};

// 2.1 Register with Full Name, email, Password
const registerNewUser = async (
  fullName: string,
  email: string,
  password: string
) => {
  try {
    const q = query(collection(db, "users"), where("email", "==", email));
    const docs = await getDocs(q);
    // check if user exists in the database
    if (docs?.docs?.length === 0) {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      const user = res.user;
      await addDoc(collection(db, "users"), {
        uid: user.uid,
        fullName: fullName,
        email: user.email,
        createdAt: new Date().toISOString(),
      });
      SendPasswordReset(email);
      return {
        result: "success",
        message: "Registered Successfully",
        user: {
          profile: {
            uid: user.uid,
            fullName: fullName,
            email: user.email,
          },
        },
      };
    } else {
      return {
        result: "error",
        message: "User already exists with same email.",
        user: null,
      };
    }
  } catch (err: any) {
    return {
      result: "error",
      message: err.message,
      user: null,
    };
  }
};

const GetUserData = async (userUuid: string) => {
  try {
    const q = query(collection(db, "users"), where("uid", "==", userUuid));
    const docs = await getDocs(q);
    const userData = docs.docs[0].data();

    return {
      result: "success",
      message: "User data fetched Successfully",
      userData: userData,
    };
  } catch (err: any) {
    return {
      result: "error",
      message: err.message,
      userData: null,
    };
  }
};

// Get all Users
const getUsers = async () => {
  // Get a list of all orders
  try {
    const q = query(collection(db, "users"));
    const docs = await getDocs(q);
    const users = docs.docs.map((doc) => doc.data());
    return {
      result: "success",
      message: "Users retrieved successfully",
      data: users,
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't get users from the database",
      data: [],
    };
  }
};

// Update a Order
const updateUser = async (user: UserType) => {
  try {
    const q = query(collection(db, "users"), where("uid", "==", user.uid));
    const docs = await getDocs(q);

    const docRef = docs.docs[0].ref;

    updateDoc(docRef, user);

    return {
      result: "success",
      message: "User updated successfully",
      data: {},
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't update user in the database",
      data: {},
    };
  }
};

// Delete User
// Delete a Order
const deleteUser = async (id: string) => {
  try {
    const q = query(collection(db, "users"), where("uid", "==", id));

    const docs = await getDocs(q);
    const docRef = docs.docs[0].ref;
    await deleteDoc(docRef);

    return {
      result: "success",
      message: "User deleted successfully",
    };
  } catch (error: any) {
    return {
      result: "error",
      message: error?.message ?? "Couldn't delete user from the database",
    };
  }
};

export {
  auth,
  getOrders,
  getOrderById,
  addOrder,
  updateOrder,
  deleteOrder,
  loginWithEmailPassword,
  SendPasswordReset,
  registerNewUser,
  Logout,
  GetUserData,
  getUsers,
  updateUser,
  deleteUser
};
