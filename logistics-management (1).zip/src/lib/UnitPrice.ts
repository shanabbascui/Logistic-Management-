const PerKgPrice = 120;
const CustomPackagingPrice = 70;

export { PerKgPrice, CustomPackagingPrice }
