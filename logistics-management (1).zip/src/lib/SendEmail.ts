import emailJs from "@emailjs/browser";

const sendEmail = async ({
  name,
  email,
  message,
}: {
  name: string;
  email: string;
  message: string;
}) => {
  emailJs.init({
    publicKey: import.meta.env.VITE_APP_EMAILJS_PUBLIC_KEY,
    blockHeadless: true,
  });

  await emailJs.send(
    import.meta.env.VITE_APP_EMAILJS_SERVICE_ID ?? "",
    import.meta.env.VITE_APP_EMAILJS_TEMPLATE_ID ?? "",
    {
      from_name: "Logistic Management",
      to_name: name,
      to_email: email,
      email: email,
      message: message,
      reply_to: "",
    }
  );
};

export { sendEmail };
