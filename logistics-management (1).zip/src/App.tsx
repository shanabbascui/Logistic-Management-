import { BrowserRouter, Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import Home from "./pages/Home";
import DashboardLayout from "./components/DashboardLayout";
import Orders from "./pages/Orders";
import CreateOrder from "./pages/CreateOrder";
import OrderDetails from "./pages/OrderDetails";
import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { GetUserData, Logout, auth } from "./lib/firebase";
import { toast } from "sonner";
import Users from "./pages/Users";
import { UserType } from "./lib/types/UserType";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [fetchingUserData, setFetchingUserData] = useState(true);
  const [user, setUser] = useState<UserType | null>(null);

  console.log(user);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setFetchingUserData(true);
      if (user) {
        GetUserData(user.uid)
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          .then((res: any) => {
            setIsLoggedIn(true);
            setFetchingUserData(false);
            setUser(res.userData);
          })
          // eslint-disable-next-line @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
          .catch((error: any) => {
            setUser(null);
            setIsLoggedIn(false);
            setFetchingUserData(false);
            Logout();
            toast.error(error.message ?? "An error occurred");
          });
      } else {
        setUser(null);
        setIsLoggedIn(false);
        setFetchingUserData(false);
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <BrowserRouter>
      <Header isLoggedIn={isLoggedIn} />
      <Routes>
        <Route
          path="/"
          element={
            <DashboardLayout
              pageName="Home"
              children={<Home />}
              isLoggedin={isLoggedIn}
              fetchingUserData={fetchingUserData}
            />
          }
        />
        <Route
          path="/orders"
          element={
            <DashboardLayout
              pageName="Orders"
              children={<Orders />}
              isLoggedin={isLoggedIn}
              fetchingUserData={fetchingUserData}
            />
          }
        />
        <Route
          path="/order/new"
          element={
            <DashboardLayout
              pageName="Add New Order"
              children={<CreateOrder />}
              isLoggedin={isLoggedIn}
              fetchingUserData={fetchingUserData}
            />
          }
        />
        <Route path="/track-order" element={<OrderDetails />} />

        <Route
          path="/users"
          element={
            <DashboardLayout
              pageName="Users"
              children={<Users />}
              isLoggedin={isLoggedIn}
              fetchingUserData={fetchingUserData}
            />
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
