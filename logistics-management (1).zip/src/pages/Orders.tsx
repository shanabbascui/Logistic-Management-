import ViewOrderModel from "@/components/models/ViewOrderModel";
import { formatDate } from "@/lib/formatDate";
import { OrderType } from "@/lib/types/OrderType";
import { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { AiFillEdit } from "react-icons/ai";
import { FaEye } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import UpdateOrder from "./UpdateOrder";
import { deleteOrder, getOrders } from "@/lib/firebase";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Loader from "@/components/Loader";
import { useNavigate } from "react-router-dom";

export default function Orders() {
  const navigate = useNavigate();

  const [selectedOrder, setSelectedOrder] = useState<OrderType | null>(null);
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  const [showEditOrder, setShowEditOrder] = useState(false);
  const [showDeleteOrder, setShowDeleteOrder] = useState(false);

  const [orders, setOrders] = useState<OrderType[]>([]);
  const [loading, setLoading] = useState(false);
  const [deletingOrder, setDeletingOrder] = useState(false);

  const columns = [
    {
      name: <span className="font-bold text-base">Tracking Id</span>,
      selector: (row: OrderType) => row.id,
      sortable: true,
      cell: (row: OrderType) => (
        <p className="flex items-center gap-x-1.5 text-base">{row?.id}</p>
      ),
      minWidth: "180px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Date
        </span>
      ),
      selector: (row: OrderType) => row.createdAt,
      sortable: true,
      cell: (row: OrderType) => {
        return (
          <span className="pl-[8px] text-base">
            {formatDate({
              unformatedDate: row?.createdAt,
              format: "DD-MM-YYYY",
            })}
          </span>
        );
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Weight
        </span>
      ),
      selector: (row: OrderType) => row.weight,
      sortable: true,
      cell: (row: OrderType) => {
        return <span className="pl-[8px] text-base">{row.weight} KG</span>;
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Sender City
        </span>
      ),
      cell: (row: OrderType) => {
        return <span className="pl-[8px] text-base">{row.sender.city}</span>;
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Receiver City
        </span>
      ),
      cell: (row: OrderType) => {
        return <span className="pl-[8px] text-base">{row.receiver.city}</span>;
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Status
        </span>
      ),
      selector: (row: OrderType) => row.status,
      sortable: true,
      cell: (row: OrderType) => {
        return (
          <span className="pl-[8px] text-base capitalize">{row.status}</span>
        );
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Action
        </span>
      ),
      cell: (row: OrderType) => {
        return (
          <div className="flex items-center gap-x-2">
            <button
              className="w-fit h-fit rounded-md bg-primary p-2 text-white"
              onClick={() => {
                setSelectedOrder(row);
                setShowOrderDetails(true);
              }}
            >
              <FaEye size={20} />
            </button>
            <button
              className="w-fit h-fit rounded-md bg-yellow-500 p-2 text-white"
              onClick={() => {
                setSelectedOrder(row);
                setShowEditOrder(true);
              }}
            >
              <AiFillEdit size={20} />
            </button>
            <button
              className="w-fit h-fit rounded-md bg-red-600 p-2 text-white"
              onClick={() => {
                setSelectedOrder(row);
                setShowDeleteOrder(true);
              }}
            >
              <MdDelete size={20} />
            </button>
          </div>
        );
      },
      minWidth: "200px",
    },
  ];

  const customStyles = {
    table: {
      style: {
        overflow: "scroll",
      },
    },
    rows: {
      style: {
        backgroundColor: "#FFFFFF",
        borderBottom: "1px solid #ddd !important",
      },
    },
    headRow: {
      style: {
        borderBottom: "1px solid #ddd !important",
        color: "#06B6D4",
      },
    },
    cells: {
      style: {
        border: "none",
        color: "#000",
      },
    },
  };

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const res = await getOrders();

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const formattedOrders: any = res.data.map((order) => {
        return {
          ...order,
        };
      });

      setOrders(formattedOrders);
      setLoading(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error.message);
      setLoading(false);
    }
  };

  const deleteSelectedOrder = async () => {
    try {
      setDeletingOrder(true);
      const res = await deleteOrder(selectedOrder?.id ?? "");

      if (res.result === "success") {
        toast.success("Order deleted successfully");
        fetchOrders();
        setSelectedOrder(null);
        setShowDeleteOrder(false);
      } else {
        toast.error(res.message);
      }
      setDeletingOrder(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error.message);
      setDeletingOrder(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <main>
      {!showEditOrder && (
        <>
          <section className="flex items-center gap-x-4">
            <h1 className="text-2xl font-semibold">All Orders</h1>
            <Button
              size={"sm"}
              onClick={() => {
                navigate("/order/new");
              }}
            >
              Add New Order
            </Button>
          </section>
          <section className="w-full mt-10">
            <DataTable
              columns={columns}
              data={orders}
              customStyles={customStyles}
              progressPending={loading}
              progressComponent={
                <section className="col-span-full w-full py-20 flex items-center justify-center text-lg gap-x-2">
                  <Loader width={20} borderWidth={2} color="primary" />
                  Fetching Orders
                </section>
              }
              noDataComponent={
                <div className="flex flex-col items-center justify-center h-[50vh]">
                  <p className="p-2 font-bold text-xl 2xl:text-2xl">
                    No Orders to display
                  </p>
                </div>
              }
              highlightOnHover
              striped
              pagination
            />
          </section>

          {selectedOrder && showOrderDetails && (
            <ViewOrderModel
              order={selectedOrder}
              closeDialog={() => {
                setSelectedOrder(null);
                setShowEditOrder(false);
              }}
            />
          )}
        </>
      )}

      {showEditOrder && selectedOrder && (
        <UpdateOrder
          order={selectedOrder}
          hideForm={() => {
            setSelectedOrder(null);
            setShowEditOrder(false);
          }}
          fetchOrders={() => {
            fetchOrders();
          }}
        />
      )}
      {showDeleteOrder && selectedOrder && (
        <section className="fixed top-0 left-0 w-full h-full bg-black/40 z-50 flex items-center justify-center">
          <section className="relative w-full max-w-sm bg-white rounded-xl shadow-md py-6 px-8 slideUpFadeInAnimation">
            <h2 className="text-xl font-bold text-center text-black mb-6">
              Are you sure you want to delete this order?
            </h2>
            <section className="flex justify-center gap-x-4">
              <Button
                size={"lg"}
                variant={"destructive"}
                onClick={() => {
                  deleteSelectedOrder();
                }}
                disabled={deletingOrder}
              >
                {deletingOrder ? "Deleting..." : "Delete"}
              </Button>
              <Button
                size={"lg"}
                variant={"outline"}
                onClick={() => {
                  setSelectedOrder(null);
                  setShowDeleteOrder(false);
                }}
                disabled={deletingOrder}
              >
                Cancel
              </Button>
            </section>
          </section>
        </section>
      )}
    </main>
  );
}
