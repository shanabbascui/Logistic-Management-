import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { sendEmail } from "@/lib/SendEmail";
import { CustomPackagingPrice, PerKgPrice } from "@/lib/UnitPrice";
import { updateOrder } from "@/lib/firebase";
import { OrderType } from "@/lib/types/OrderType";
import { useState } from "react";
import { CgCloseO } from "react-icons/cg";
import { IoArrowBack } from "react-icons/io5";
import { toast } from "sonner";

type Order = {
  order: OrderType;
  hideForm: () => void;
  fetchOrders: () => void;
};

export default function UpdateOrder({ order, hideForm, fetchOrders }: Order) {
  const [senderName, setSenderName] = useState(order.sender.name);
  const [senderPhone, setSenderPhone] = useState(order.sender.phone);
  const [senderAddress, setSenderAddress] = useState(order.sender.address);
  const [senderCity, setSenderCity] = useState(order.sender.city);

  const [receiverName, setReceiverName] = useState(order.receiver.name);
  const [receiverPhone, setReceiverPhone] = useState(order.receiver.phone);
  const [receiverAddress, setReceiverAddress] = useState(
    order.receiver.address
  );
  const [receiverCity, setReceiverCity] = useState(order.receiver.city);

  const [weight, setWeight] = useState(order.weight.toString());
  const [packagingType, setPackagingType] = useState(
    order.isWithCustomPackaging ? "custom" : "standard"
  );
  const [paymentOption, setPaymentOption] = useState<string>(
    order.paymentOption
  );
  const [orderAmount, setOrderAmount] = useState(order.orderAmount.toString());

  const [showUpdateStatus, setShowUpdateStatus] = useState(false);
  const [status, setStatus] = useState<
    "pending" | "shipped" | "delivered" | "cancelled" | "returned"
  >(order.status);
  const [city, setCity] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  const [updatingOrder, setUpdatingOrder] = useState(false);

  const addUpdate = async () => {
    if (status && city && message) {
      try {
        setUpdatingOrder(true);
        const res = await updateOrder({
          ...order,
          id: order.id,
          status: status,
          updates: [
            ...order.updates,
            {
              createdAt: new Date().toISOString(),
              location: city,
              message: message,
            },
          ],
        });

        await sendEmail({
          email: order.sender.email,
          name: order.sender.name,
          message: `Your order with tracking ID ${order.id} has been marked as ${status}. It is currently in ${city}. Message from the courier: ${message}`,
        });

        await sendEmail({
          email: order.receiver.email,
          name: order.receiver.name,
          message: `Your order with tracking ID ${order.id} has been marked as ${status}. It is currently in ${city}. Message from the courier: ${message}`,
        });

        if (res.result === "success") {
          toast.success("Order status has been updated.");
          setShowUpdateStatus(false);
          setMessage("");
          setCity("");
        } else {
          toast.error(res.message ?? "Couldn't update order.");
        }
        setUpdatingOrder(false);
        fetchOrders();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } catch (error: any) {
        toast.error(error.message ?? "Couldn't update order.");
      }
    } else {
      toast.warning("Please fill all the required fields.");
    }
  };

  const editOrder = async () => {
    try {
      setUpdatingOrder(true);
      const res = await updateOrder({
        createdAt: order.createdAt,
        id: order.id,
        isWithCustomPackaging: packagingType === "custom" ? true : false,
        orderAmount: parseFloat(orderAmount),
        paymentOption: paymentOption === "cod" ? "cod" : "prepaid",
        receiver: {
          address: receiverAddress,
          city: receiverCity,
          name: receiverName,
          phone: receiverPhone,
          email: order.receiver.email,
        },
        sender: {
          address: senderAddress,
          city: senderCity,
          name: senderName,
          phone: senderPhone,
          email: order.sender.email,
        },
        status: order.status,
        updates: order.updates,
        weight: parseFloat(weight),
      });

      if (res.result === "success") {
        toast.success("Order has been updated.");
      } else {
        toast.error(res.message ?? "Couldn't update order.");
      }
      setUpdatingOrder(false);
      fetchOrders();

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      setUpdatingOrder(false);
      toast.error(error.message ?? "Couldn't update order.");
    }
  };

  return (
    <main>
      <section className="flex justify-between items-center border-b border-black/10 pb-3">
        <div className="flex items-center gap-x-2">
          <button className="w-fit -mb-0.5" onClick={hideForm}>
            <IoArrowBack size={26} />
          </button>
          <h1 className="text-2xl font-semibold">Edit Order - {order.id}</h1>
        </div>

        <section>
          <Button
            size={"lg"}
            variant={"default"}
            className="mt-2"
            onClick={() => {
              setShowUpdateStatus(true);
            }}
          >
            Update Status
          </Button>
        </section>
      </section>
      <form
        className="w-full mt-10 grid grid-cols-2 gap-5"
        onSubmit={(e) => {
          e.preventDefault();

          if (
            senderName &&
            senderPhone &&
            senderAddress &&
            senderCity &&
            receiverName &&
            receiverPhone &&
            receiverAddress &&
            receiverCity &&
            weight &&
            packagingType &&
            paymentOption &&
            (paymentOption === "cod" ? parseFloat(orderAmount) > 0 : true) &&
            parseFloat(weight) > 0
          ) {
            editOrder();
          } else {
            toast.warning("Please fill all the required fields.");
          }
        }}
        onReset={() => {
          setSenderName("");
          setSenderPhone("");
          setSenderAddress("");
          setSenderCity("");
          setReceiverName("");
          setReceiverPhone("");
          setReceiverAddress("");
          setReceiverCity("");
          setWeight("");
          setPackagingType("");
          setPaymentOption("");
          setOrderAmount("");
          hideForm();
        }}
      >
        <section className="flex flex-col gap-y-4">
          <h2 className="text-lg font-semibold">Sender Details</h2>
          <Label htmlFor="senderName">
            Name
            <Input
              type="text"
              name="senderName"
              id="senderName"
              placeholder="Enter sender name"
              className="w-full mt-2"
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
            />
          </Label>
          <Label htmlFor="senderPhone">
            Phone Number
            <Input
              type="tel"
              name="senderPhone"
              id="senderPhone"
              placeholder="Enter sender phone number"
              className="w-full mt-2"
              value={senderPhone}
              onChange={(e) => setSenderPhone(e.target.value)}
            />
          </Label>

          <Label htmlFor="senderAddress">
            Address
            <Input
              type="text"
              name="senderAddress"
              id="senderAddress"
              placeholder="Enter sender address"
              className="w-full mt-2"
              value={senderAddress}
              onChange={(e) => setSenderAddress(e.target.value)}
            />
          </Label>

          {/* City */}
          <Label htmlFor="senderCity">
            City
            <Input
              type="text"
              name="senderCity"
              id="senderCity"
              placeholder="Enter sender city"
              className="w-full mt-2"
              value={senderCity}
              onChange={(e) => setSenderCity(e.target.value)}
            />
          </Label>

          {/* Receiver Details */}
          <h2 className="text-lg font-semibold mt-5">Receiver Details</h2>

          <Label htmlFor="receiverName">
            Name
            <Input
              type="text"
              name="receiverName"
              id="receiverName"
              placeholder="Enter receiver name"
              className="w-full mt-2"
              value={receiverName}
              onChange={(e) => setReceiverName(e.target.value)}
            />
          </Label>

          <Label htmlFor="receiverPhone">
            Phone Number
            <Input
              type="tel"
              name="receiverPhone"
              id="receiverPhone"
              placeholder="Enter receiver phone number"
              className="w-full mt-2"
              value={receiverPhone}
              onChange={(e) => setReceiverPhone(e.target.value)}
            />
          </Label>

          <Label htmlFor="receiverAddress">
            Address
            <Input
              type="text"
              name="receiverAddress"
              id="receiverAddress"
              placeholder="Enter receiver address"
              className="w-full mt-2"
              value={receiverAddress}
              onChange={(e) => setReceiverAddress(e.target.value)}
            />
          </Label>

          {/* City */}
          <Label htmlFor="receiverCity">
            City
            <Input
              type="text"
              name="receiverCity"
              id="receiverCity"
              placeholder="Enter receiver city"
              className="w-full mt-2"
              value={receiverCity}
              onChange={(e) => setReceiverCity(e.target.value)}
            />
          </Label>
        </section>

        <section className="flex flex-col gap-y-4">
          <h2 className="text-lg font-semibold">Order Details</h2>
          <Label htmlFor="weight">
            Total Weight
            <Input
              type="number"
              name="weight"
              id="weight"
              placeholder="Enter total weight"
              className="w-full mt-2"
              value={weight}
              onChange={(e) => {
                if (parseFloat(e.target.value) >= 0) {
                  setWeight(e.target.value);
                } else {
                  setWeight("");
                }
              }}
            />
          </Label>
          <Label htmlFor="packagingType">
            Packaging Type
            <Select
              onValueChange={(e) => {
                setPackagingType(e);
              }}
              value={packagingType}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select Packaging Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </Label>

          <Label htmlFor="paymentOption">
            Payment Option
            <Select
              onValueChange={(e) => {
                setPaymentOption(e);
              }}
              value={paymentOption}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select Payment Option" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="cod">Cash on Delivery</SelectItem>
                  <SelectItem value="prepaid">Prepaid</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </Label>

          <Label htmlFor="orderAmount">
            Order Amount (To be paid by receiver) (optional)
            <Input
              type="number"
              name="orderAmount"
              id="orderAmount"
              placeholder="Enter total order amount"
              className="w-full mt-2"
              value={orderAmount}
              onChange={(e) => {
                if (parseFloat(e.target.value) >= 0) {
                  setOrderAmount(e.target.value);
                } else {
                  setOrderAmount("");
                }
              }}
            />
          </Label>

          {/* Order Summary */}
          <h2 className="text-lg font-semibold mt-5">Order Summary</h2>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Total Weight</span>
            <span>{weight ? weight : 0} kg</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Per KG Cost</span>
            <span>PKR {PerKgPrice}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Packaging Cost</span>
            <span>
              PKR {packagingType === "custom" ? CustomPackagingPrice : 0}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Payment Option</span>
            <span className="uppercase">{paymentOption}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Order Amount</span>
            <span>PKR {orderAmount ? orderAmount : 0}</span>
          </div>

          <hr />
          <div className="flex justify-between items-center">
            <span className="font-semibold">Paid by Sender</span>
            <span className="font-semibold">
              PKR{" "}
              {(
                (isNaN(parseFloat(weight)) ? 0 : parseFloat(weight)) *
                PerKgPrice +
                (packagingType === "custom" ? CustomPackagingPrice : 0)
              ).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-semibold">To be Paid by Receiver </span>
            <span className="font-semibold">
              PKR{" "}
              {paymentOption === "cod"
                ? (orderAmount ? parseFloat(orderAmount) : 0).toFixed(2)
                : 0}
            </span>
          </div>
        </section>

        <section className="col-span-full flex items-center gap-5 pt-10 pb-32">
          <Button
            size={"lg"}
            variant={"default"}
            type="submit"
            disabled={updatingOrder}
          >
            {updatingOrder ? "Updating Order..." : "Update Order"}
          </Button>

          <Button
            size={"lg"}
            variant={"ghost"}
            type="reset"
            disabled={updatingOrder}
          >
            Cancel
          </Button>
        </section>
      </form>

      {showUpdateStatus && (
        <section className="fixed top-0 left-0 w-full h-full bg-black/40 z-50 flex items-center justify-center">
          <section className="relative w-full max-w-sm bg-white rounded-xl shadow-md py-6 px-8 slideUpFadeInAnimation">
            <h2 className="text-xl font-bold text-center text-black mb-6">
              Add Order Update
            </h2>

            <button
              className="w-fit h-fit absolute top-4 right-4 text-black"
              onClick={() => {
                setShowUpdateStatus(false);
                setStatus(order.status);
                setCity("");
                setMessage("");
              }}
            >
              <CgCloseO size={26} />
            </button>
            <section className="flex flex-col gap-y-4">
              <Label className="">
                Update Order Status
                <Select
                  onValueChange={(e) => {
                    if (e == "pending") {
                      setStatus("pending");
                    } else if (e == "shipped") {
                      setStatus("shipped");
                    } else if (e == "delivered") {
                      setStatus("delivered");
                    } else if (e == "cancelled") {
                      setStatus("cancelled");
                    } else if (e == "returned") {
                      setStatus("returned");
                    }
                  }}
                  value={status}
                >
                  <SelectTrigger className="w-full mt-2">
                    <SelectValue placeholder="Select Packaging Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Order Status</SelectLabel>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                      <SelectItem value="returned">Returned</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </Label>
              <Label htmlFor="city">
                City
                <Input
                  type="text"
                  name="city"
                  id="city"
                  placeholder="Enter city"
                  className="w-full mt-2"
                  value={city}
                  onChange={(e) => {
                    setCity(e.target.value);
                  }}
                />
              </Label>
              <Label htmlFor="message">
                Message
                <Input
                  type="text"
                  name="message"
                  id="message"
                  placeholder="Enter message"
                  className="w-full mt-2"
                  value={message}
                  onChange={(e) => {
                    setMessage(e.target.value);
                  }}
                />
              </Label>
              <Button
                size={"lg"}
                variant={"default"}
                className="mt-2"
                onClick={() => {
                  addUpdate();
                }}
                disabled={updatingOrder}
              >
                {updatingOrder ? "Adding Update..." : "Add Update"}
              </Button>
              <Button
                size={"lg"}
                variant={"ghost"}
                className="-mt-4 w-fit self-center"
                onClick={() => {
                  setShowUpdateStatus(false);
                  setStatus(order.status);
                  setCity("");
                  setMessage("");
                }}
                disabled={updatingOrder}
              >
                Cancel
              </Button>
            </section>
          </section>
        </section>
      )}
    </main>
  );
}
