import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getOrderById } from "@/lib/firebase";
import { formatDate, getTimeFromDate } from "@/lib/formatDate";
import { OrderType } from "@/lib/types/OrderType";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function OrderDetails() {
  const [order, setOrder] = useState<OrderType | null>(null);
  const [trackingId, setTrackingId] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const fetchOrder = async (trackingId: string) => {

    if(!trackingId) return toast.error("Please enter a valid tracking id");

    try {
      setLoading(true);
      const res = await getOrderById(trackingId);

      if (res.result === 'success') {
        setOrder(res.data as OrderType);
      } else {
        toast.error(res.message);
      }
      setLoading(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error?.message ?? "Couldn't get order details");
      setLoading(false);
    }
  };

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const trackingId = urlParams.get("id");

    if (trackingId) {
      setTrackingId(trackingId);
      fetchOrder(trackingId);
    }

  }, []);

  return (
    <main>
      {order ? (
        <section className="relative w-full max-w-3xl bg-white rounded-xl lg:shadow-md py-6 px-5 slideUpFadeInAnimation mx-auto my-16 border-0 lg:border border-black/10">
          <h2 className="text-xl font-bold text-center text-black">
            Order Details
          </h2>

          <section className="grid grid-cols-2 gap-16 lg:gap-0  mt-5">
            <section className="order-2 lg:order-1 col-span-full lg:col-span-1 flex flex-col gap-y-1.5">
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Tracking Id:</p>
                <p className="text-base font-normal">{order.id}</p>
              </div>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Status:</p>
                <p className="text-base font-normal capitalize">{order.status}</p>
              </div>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Weight:</p>
                <p className="text-base font-normal">{order.weight} KG</p>
              </div>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Packaging Type:</p>
                <p className="text-base font-normal">
                  {order.isWithCustomPackaging ? "Custom" : "Standard"}
                </p>
              </div>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Payment Option:</p>
                <p className="text-base font-normal">
                  {order.paymentOption === "cod" ? "Cash On Delivery" : "Prepaid"}
                </p>
              </div>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Order Amount:</p>
                <p className="text-base font-normal">
                  PKR {order.paymentOption === "cod" ? order.orderAmount : 0}
                </p>
              </div>

              <hr className="mt-3" />
              <p className="text-lg font-bold mt-2">Sender</p>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Name:</p>
                <p className="text-base font-normal">{order.sender.name}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Phone:</p>
                <p className="text-base font-normal">{order.sender.phone}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Email:</p>
                <p className="text-base font-normal">{order.sender.email}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">City:</p>
                <p className="text-base font-normal">{order.sender.city}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32 min-w-32">Address:</p>
                <p className="text-base font-normal">{order.sender.address}</p>
              </div>
              <hr className="mt-3" />
              <p className="text-lg font-bold mt-2">Receiver</p>

              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Name:</p>
                <p className="text-base font-normal">{order.receiver.name}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Phone:</p>
                <p className="text-base font-normal">{order.receiver.phone}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">Email:</p>
                <p className="text-base font-normal">{order.receiver.email}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32">City:</p>
                <p className="text-base font-normal">{order.receiver.city}</p>
              </div>
              <div className="w-full flex items-baseline gap-2">
                <p className="text-base font-bold w-32 min-w-32">Address:</p>
                <p className="text-base font-normal">{order.receiver.address}</p>
              </div>
            </section>

            <section className="order-1 lg:order-2 col-span-full lg:col-span-1 w-full border-0 lg:border-l border-black/10 lg:pl-5">
              <h3 className="text-base font-bold text-center">Updates</h3>
              <section className="h-full ml-3 border-l border-black/30 flex flex-col gap- y-3">
                {order.updates.map((update, index) => {
                  return (
                    <section key={index} className="pl-5 relative py-3">
                      <div className="absolute -left-1.5 top-[1.1rem] w-3 h-3 bg-gray-700 rounded-full"></div>
                      <p className="text-base font-bold">{update.location}</p>
                      <p className="text-sm">
                        {formatDate({
                          format: "DD MMM YYYY",
                          unformatedDate: update.createdAt,
                        })}{" "}
                        - {getTimeFromDate(update.createdAt)}
                      </p>
                      <p className="text-sm">{update.message}</p>
                    </section>
                  );
                })}
              </section>
            </section>
          </section>
        </section>
      ) : (
        <section className="relative w-full max-w-xs lg:max-w-3xl bg-white rounded-xl shadow-md py-6 px-5 mx-auto my-16 border border-black/10">
          <h2 className="text-xl font-bold text-center text-black">
            Enter Tracking Id to view order Updates
          </h2>
          <form className="flex items-center justify-start gap-x-3 my-5"
            onSubmit={(e) => {
              e.preventDefault();
              fetchOrder(trackingId);
            }}
          >
            <Input
              type="search"
              placeholder="Enter Tracking Id"
              className="grow"
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
            />
            <Button type="submit"
              disabled={loading}
            >
              {loading ? "Tracking..." : "Track Order"}
            </Button>
          </form>
        </section>
      )}
    </main>

  )
}