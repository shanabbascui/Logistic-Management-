import { formatDate } from "@/lib/formatDate";
import { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import { AiFillEdit } from "react-icons/ai";
import { MdDelete } from "react-icons/md";
import { deleteUser, getUsers } from "@/lib/firebase";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Loader from "@/components/Loader";
import { UserType } from "@/lib/types/UserType";
import UpdateUserModel from "@/components/models/UpdateUserModel";
import AddUserModel from "@/components/models/AddUserModel";

export default function Users() {
  const [showEditUser, setShowEditUser] = useState(false);
  const [showDeleteUser, setShowDeleteUser] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false);

  const [loading, setLoading] = useState(false);
  const [deletingUser, setDeletingUser] = useState(false);

  const [users, setUsers] = useState<UserType[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null);

  const columns = [
    {
      name: <span className="font-bold text-base">Full Name</span>,
      selector: (row: UserType) => row.fullName,
      sortable: true,
      cell: (row: UserType) => (
        <p className="flex items-center gap-x-1.5 text-base">{row?.fullName}</p>
      ),
      minWidth: "180px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Email
        </span>
      ),
      selector: (row: UserType) => row.email,
      sortable: true,
      cell: (row: UserType) => {
        return <span className="pl-[8px] text-base">{row.email}</span>;
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Registration Data
        </span>
      ),
      selector: (row: UserType) => row.createdAt,
      sortable: true,
      cell: (row: UserType) => {
        return (
          <span className="pl-[8px] text-base">
            {formatDate({
              unformatedDate: row?.createdAt,
              format: "DD-MM-YYYY",
            })}
          </span>
        );
      },
      minWidth: "126px",
    },
    {
      name: (
        <span className="border-l-[1px] pl-[8px] border-[#D1D1D1] font-bold text-base">
          Action
        </span>
      ),
      cell: (row: UserType) => {
        return (
          <div className="flex items-center gap-x-2">
            <button
              className="w-fit h-fit rounded-md bg-yellow-500 p-2 text-white"
              onClick={() => {
                setSelectedUser(row);
                setShowEditUser(true);
              }}
            >
              <AiFillEdit size={20} />
            </button>
            <button
              className="w-fit h-fit rounded-md bg-red-600 p-2 text-white"
              onClick={() => {
                setSelectedUser(row);
                setShowDeleteUser(true);
              }}
            >
              <MdDelete size={20} />
            </button>
          </div>
        );
      },
      minWidth: "200px",
    },
  ];

  const customStyles = {
    table: {
      style: {
        overflow: "scroll",
      },
    },
    rows: {
      style: {
        backgroundColor: "#FFFFFF",
        borderBottom: "1px solid #ddd !important",
      },
    },
    headRow: {
      style: {
        borderBottom: "1px solid #ddd !important",
        color: "#06B6D4",
      },
    },
    cells: {
      style: {
        border: "none",
        color: "#000",
      },
    },
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await getUsers();

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const formattedUsers: any = res.data.map((order) => {
        return {
          ...order,
        };
      });

      setUsers(formattedUsers);
      setLoading(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error.message);
      setLoading(false);
    }
  };

  const deleteSelectedUser = async () => {
    try {
      setDeletingUser(true);
      const res = await deleteUser(selectedUser?.uid ?? "")

      if (res.result === "success") {
        toast.success("User deleted successfully");
        fetchUsers();
        setSelectedUser(null);
        setShowDeleteUser(false);
      } else {
        toast.error(res.message);
      }
      setDeletingUser(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error.message);
      setDeletingUser(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <main>
      <div className="flex items-center gap-x-4">
        <h1 className="text-2xl font-semibold">All Users</h1>
        <Button
          size={"sm"}
          onClick={() => {
            setShowAddUser(true);
          }}
        >
          Add New User
        </Button>
      </div>
      <section className="w-full mt-10">
        <DataTable
          columns={columns}
          data={users}
          customStyles={customStyles}
          progressPending={loading}
          progressComponent={
            <section className="col-span-full w-full py-20 flex items-center justify-center text-lg gap-x-2">
              <Loader width={20} borderWidth={2} color="primary" />
              Fetching Users
            </section>
          }
          noDataComponent={
            <div className="flex flex-col items-center justify-center h-[50vh]">
              <p className="p-2 font-bold text-xl 2xl:text-2xl">
                No Users to display
              </p>
            </div>
          }
          highlightOnHover
          striped
          pagination
        />
      </section>

      {showEditUser && selectedUser && (
        <UpdateUserModel
          user={selectedUser}
          closeDialog={() => {
            setSelectedUser(null);
            setShowEditUser(false);
          }}
          fetchAllUsers={()=>{
            fetchUsers();
          }}
        />
      )}

      {showAddUser && (
        <AddUserModel
          closeDialog={() => {
            setShowAddUser(false);
          }}
          fetchAllUsers={()=>{
            fetchUsers();
          }}
        />
      )}

      {showDeleteUser && selectedUser && (
        <section className="fixed top-0 left-0 w-full h-full bg-black/40 z-50 flex items-center justify-center">
          <section className="relative w-full max-w-sm bg-white rounded-xl shadow-md py-6 px-8 slideUpFadeInAnimation">
            <h2 className="text-xl font-bold text-center text-black mb-6">
              Are you sure you want to remove {selectedUser.fullName}?
            </h2>
            <section className="flex justify-center gap-x-4">
              <Button
                size={"lg"}
                variant={"destructive"}
                onClick={() => {
                  deleteSelectedUser();
                }}
                disabled={deletingUser}
              >
                {deletingUser ? "Deleting..." : "Delete"}
              </Button>
              <Button
                size={"lg"}
                variant={"outline"}
                onClick={() => {
                  setSelectedUser(null);
                  setShowDeleteUser(false);
                }}
                disabled={deletingUser}
              >
                Cancel
              </Button>
            </section>
          </section>
        </section>
      )}
    </main>
  );
}
