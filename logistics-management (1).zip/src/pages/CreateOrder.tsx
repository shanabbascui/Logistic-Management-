import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { sendEmail } from "@/lib/SendEmail";
import { CustomPackagingPrice, PerKgPrice } from "@/lib/UnitPrice";
import { addOrder } from "@/lib/firebase";
import { generateUniqueId } from "@/lib/generateID";
import { useState } from "react";
import { toast } from "sonner";

export default function CreateOrder() {
  const [senderName, setSenderName] = useState("");
  const [senderPhone, setSenderPhone] = useState("");
  const [senderEmail, setSenderEmail] = useState("");
  const [senderAddress, setSenderAddress] = useState("");
  const [senderCity, setSenderCity] = useState("");

  const [receiverName, setReceiverName] = useState("");
  const [receiverPhone, setReceiverPhone] = useState("");
  const [receiverEmail, setReceiverEmail] = useState("");
  const [receiverAddress, setReceiverAddress] = useState("");
  const [receiverCity, setReceiverCity] = useState("");

  const [weight, setWeight] = useState("0");
  const [packagingType, setPackagingType] = useState("");
  const [paymentOption, setPaymentOption] = useState("");
  const [orderAmount, setOrderAmount] = useState("0");

  const createNewOrder = async () => {
    try {
      const res = await addOrder({
        id: generateUniqueId(),
        createdAt: new Date().toISOString(),
        sender: {
          name: senderName,
          phone: senderPhone,
          address: senderAddress,
          city: senderCity,
          email: senderEmail,
        },
        receiver: {
          name: receiverName,
          phone: receiverPhone,
          address: receiverAddress,
          city: receiverCity,
          email: receiverEmail,
        },
        weight: parseFloat(weight),
        isWithCustomPackaging: packagingType === "custom" ? true : false,
        orderAmount: paymentOption === "cod" ? parseFloat(orderAmount) : 0,
        paymentOption: paymentOption === "cod" ? "cod" : "prepaid",
        status: "pending",
        updates: [
          {
            createdAt: new Date().toISOString(),
            location: senderCity,
            message: "Order is Pending to be scheduled for delivery."
          }
        ],
      });

      await sendEmail({
        email: senderEmail,
        name: senderName,
        message: `Your order for ${receiverName} of weight ${weight} kg for city ${receiverCity} has been successfully scheduled for delivery. You will be notified once the order is dispatched.`
      })

      await sendEmail({
        email: receiverEmail,
        name: receiverName,
        message: `You have a new order from ${senderName} for weight ${weight} kg. The order is scheduled for delivery in ${receiverCity}. You will be notified once the order is dispatched.`
      });

      if (res.result === "success") {
        toast.success(res.message);
        setSenderName("");
        setSenderPhone("");
        setSenderEmail("");
        setSenderAddress("");
        setSenderCity("");
        setReceiverName("");
        setReceiverPhone("");
        setReceiverEmail("");
        setReceiverAddress("");
        setReceiverCity("");
        setWeight("0");
        setPackagingType("");
        setPaymentOption("");
        setOrderAmount("0");
      } else {
        toast.error(res.message);
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      toast.error(error.message)
    }
  }

  return (
    <main>
      <h1 className="text-2xl font-semibold">Add New Order</h1>
      <form
        className="w-full mt-10 grid grid-cols-2 gap-5"
        onSubmit={(e) => {
          e.preventDefault();

          if (
            senderName &&
            senderPhone &&
            senderEmail &&
            senderAddress &&
            senderCity &&
            receiverName &&
            receiverPhone &&
            receiverEmail &&
            receiverAddress &&
            receiverCity &&
            weight &&
            packagingType &&
            paymentOption &&
            (paymentOption === "cod" ? parseFloat(orderAmount) > 0 : true) &&
            parseFloat(weight) > 0
          ) {
            createNewOrder();
          } else {
            toast.warning("Please fill all the required fields.");
          }
        }}
        onReset={() => {
          setSenderName("");
          setSenderPhone("");
          setSenderEmail("");
          setSenderAddress("");
          setSenderCity("");
          setReceiverName("");
          setReceiverPhone("");
          setReceiverEmail("");
          setReceiverAddress("");
          setReceiverCity("");
          setWeight("");
          setPackagingType("");
          setPaymentOption("");
          setOrderAmount("");
        }}
      >
        <section className="flex flex-col gap-y-4">
          <h2 className="text-lg font-semibold">Sender Details</h2>
          <Label htmlFor="senderName">
            Name
            <Input
              type="text"
              name="senderName"
              id="senderName"
              placeholder="Enter sender name"
              className="w-full mt-2"
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
            />
          </Label>
          <Label htmlFor="senderPhone">
            Phone Number
            <Input
              type="tel"
              name="senderPhone"
              id="senderPhone"
              placeholder="Enter sender phone number"
              className="w-full mt-2"
              value={senderPhone}
              onChange={(e) => setSenderPhone(e.target.value)}
            />
          </Label>
          <Label htmlFor="senderEmail">
            Email
            <Input
              type="email"
              name="senderEmail"
              id="senderEmail"
              placeholder="Enter sender Email"
              className="w-full mt-2"
              value={senderEmail}
              onChange={(e) => setSenderEmail(e.target.value)}
              required
            />
          </Label>

          <Label htmlFor="senderAddress">
            Address
            <Input
              type="text"
              name="senderAddress"
              id="senderAddress"
              placeholder="Enter sender address"
              className="w-full mt-2"
              value={senderAddress}
              onChange={(e) => setSenderAddress(e.target.value)}
            />
          </Label>

          {/* City */}
          <Label htmlFor="senderCity">
            City
            <Input
              type="text"
              name="senderCity"
              id="senderCity"
              placeholder="Enter sender city"
              className="w-full mt-2"
              value={senderCity}
              onChange={(e) => setSenderCity(e.target.value)}
            />
          </Label>

          {/* Receiver Details */}
          <h2 className="text-lg font-semibold mt-5">Receiver Details</h2>

          <Label htmlFor="receiverName">
            Name
            <Input
              type="text"
              name="receiverName"
              id="receiverName"
              placeholder="Enter receiver name"
              className="w-full mt-2"
              value={receiverName}
              onChange={(e) => setReceiverName(e.target.value)}
            />
          </Label>

          <Label htmlFor="receiverPhone">
            Phone Number
            <Input
              type="tel"
              name="receiverPhone"
              id="receiverPhone"
              placeholder="Enter receiver phone number"
              className="w-full mt-2"
              value={receiverPhone}
              onChange={(e) => setReceiverPhone(e.target.value)}
            />
          </Label>
          <Label htmlFor="receiverEmail">
            Email
            <Input
              type="email"
              name="receiverEmail"
              id="receiverEmail"
              placeholder="Enter receiver Email"
              className="w-full mt-2"
              value={receiverEmail}
              onChange={(e) => setReceiverEmail(e.target.value)}
              required
            />
          </Label>

          <Label htmlFor="receiverAddress">
            Address
            <Input
              type="text"
              name="receiverAddress"
              id="receiverAddress"
              placeholder="Enter receiver address"
              className="w-full mt-2"
              value={receiverAddress}
              onChange={(e) => setReceiverAddress(e.target.value)}
            />
          </Label>

          {/* City */}
          <Label htmlFor="receiverCity">
            City
            <Input
              type="text"
              name="receiverCity"
              id="receiverCity"
              placeholder="Enter receiver city"
              className="w-full mt-2"
              value={receiverCity}
              onChange={(e) => setReceiverCity(e.target.value)}
            />
          </Label>
        </section>

        <section className="flex flex-col gap-y-4">
          <h2 className="text-lg font-semibold">Order Details</h2>
          <Label htmlFor="weight">
            Total Weight
            <Input
              type="number"
              name="weight"
              id="weight"
              placeholder="Enter total weight"
              className="w-full mt-2"
              value={weight}
              onChange={(e) => {
                if (parseFloat(e.target.value) >= 0) {
                  setWeight(e.target.value);
                } else {
                  setWeight("");
                }
              }}
            />
          </Label>
          <Label htmlFor="packagingType">
            Packaging Type
            <Select
              onValueChange={(e) => {
                setPackagingType(e);
              }}
              value={packagingType}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select Packaging Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </Label>

          <Label htmlFor="paymentOption">
            Payment Option
            <Select
              onValueChange={(e) => {
                setPaymentOption(e);
              }}
              value={paymentOption}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select Payment Option" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="cod">Cash on Delivery</SelectItem>
                  <SelectItem value="prepaid">Prepaid</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </Label>

          <Label htmlFor="orderAmount">
            Order Amount (To be paid by receiver) (optional)
            <Input
              type="number"
              name="orderAmount"
              id="orderAmount"
              placeholder="Enter total order amount"
              className="w-full mt-2"
              value={orderAmount}
              onChange={(e) => {
                if (parseFloat(e.target.value) >= 0) {
                  setOrderAmount(e.target.value);
                } else {
                  setOrderAmount("");
                }
              }}
            />
          </Label>

          {/* Order Summary */}
          <h2 className="text-lg font-semibold mt-5">Order Summary</h2>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Total Weight</span>
            <span>{weight ? weight : 0} kg</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Per KG Cost</span>
            <span>PKR {PerKgPrice}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Packaging Cost</span>
            <span>
              PKR {packagingType === "custom" ? CustomPackagingPrice : 0}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Payment Option</span>
            <span className="uppercase">{paymentOption}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">Order Amount</span>
            <span>PKR {orderAmount ? orderAmount : 0}</span>
          </div>

          <hr />
          <div className="flex justify-between items-center">
            <span className="font-semibold">Paid by Sender</span>
            <span className="font-semibold">
              PKR{" "}
              {(
                (isNaN(parseFloat(weight)) ? 0 : parseFloat(weight)) *
                PerKgPrice +
                (packagingType === "custom" ? CustomPackagingPrice : 0)
              ).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-semibold">To be Paid by Receiver </span>
            <span className="font-semibold">
              PKR{" "}
              {paymentOption === "cod"
                ? (orderAmount ? parseFloat(orderAmount) : 0).toFixed(2)
                : 0}
            </span>
          </div>
        </section>

        <section className="col-span-full flex items-center gap-5 pt-10 pb-32">
          <Button size={"lg"} variant={"default"} type="submit">
            Create Order
          </Button>

          <Button size={"lg"} variant={"ghost"} type="reset">
            Cancel
          </Button>
        </section>
      </form>
    </main>
  );
}
